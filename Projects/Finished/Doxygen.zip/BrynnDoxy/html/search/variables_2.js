var searchData=
[
  ['mines',['mines',['../struct_settings.html#ada9a3fb9dbfef8d3f3aa5da54831a1a4',1,'Settings']]]
];
