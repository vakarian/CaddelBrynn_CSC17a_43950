var searchData=
[
  ['columns',['columns',['../struct_settings.html#a3506d9c6fc18cf140974e3872fdefc99',1,'Settings']]]
];
