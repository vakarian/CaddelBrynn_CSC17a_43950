var searchData=
[
  ['destroy',['destroy',['../main_8cpp.html#a1eecc7bdbd5e2b717b58fc5a7a046a44',1,'main.cpp']]],
  ['difficulty',['Difficulty',['../struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2',1,'Settings']]]
];
