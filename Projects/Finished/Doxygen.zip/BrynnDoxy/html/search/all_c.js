var searchData=
[
  ['settings',['Settings',['../struct_settings.html',1,'']]]
];
