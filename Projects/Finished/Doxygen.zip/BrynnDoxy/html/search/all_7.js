var searchData=
[
  ['loser',['LOSER',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810aa6636add48a506de3d5a371d31b3f926',1,'Settings']]]
];
