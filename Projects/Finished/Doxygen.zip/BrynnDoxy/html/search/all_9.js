var searchData=
[
  ['nmines',['nMines',['../main_8cpp.html#af5b45ebf27cb686a2b6c7f3dc5c42c22',1,'main.cpp']]],
  ['nomine',['NOMINE',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810a3f29bdf1c96bc1fb773a31f0609a37b7',1,'Settings::NOMINE()'],['../main_8cpp.html#a39a0d060cad273c0b218e241bcf1f9da',1,'noMine():&#160;main.cpp']]],
  ['none',['NONE',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810ac7dbfe40df629f75532ba1717c5230d7',1,'Settings']]]
];
