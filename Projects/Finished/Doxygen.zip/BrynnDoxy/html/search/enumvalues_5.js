var searchData=
[
  ['nomine',['NOMINE',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810a3f29bdf1c96bc1fb773a31f0609a37b7',1,'Settings']]],
  ['none',['NONE',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810ac7dbfe40df629f75532ba1717c5230d7',1,'Settings']]]
];
