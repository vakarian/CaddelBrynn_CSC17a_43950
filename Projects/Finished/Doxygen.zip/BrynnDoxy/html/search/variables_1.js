var searchData=
[
  ['field',['field',['../struct_settings.html#a8a6a323859d87c7cb4fcb80a919a36de',1,'Settings']]]
];
