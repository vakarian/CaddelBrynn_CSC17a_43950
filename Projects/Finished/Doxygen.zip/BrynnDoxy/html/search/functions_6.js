var searchData=
[
  ['nmines',['nMines',['../main_8cpp.html#af5b45ebf27cb686a2b6c7f3dc5c42c22',1,'main.cpp']]],
  ['nomine',['noMine',['../main_8cpp.html#a39a0d060cad273c0b218e241bcf1f9da',1,'main.cpp']]]
];
