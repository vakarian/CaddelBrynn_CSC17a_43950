var searchData=
[
  ['mine',['MINE',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810af47ab0cb506f93cfa6f6b416ce4f224f',1,'Settings']]]
];
