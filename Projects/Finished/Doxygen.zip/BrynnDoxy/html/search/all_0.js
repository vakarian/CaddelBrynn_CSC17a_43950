var searchData=
[
  ['beginner',['BEGINNER',['../struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2a0974a94cea76e0d6751d5f185db40ce7',1,'Settings']]]
];
