var searchData=
[
  ['difficulty',['Difficulty',['../struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2',1,'Settings']]]
];
