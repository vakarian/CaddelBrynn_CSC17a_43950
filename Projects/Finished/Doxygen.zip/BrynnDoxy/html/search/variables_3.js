var searchData=
[
  ['rows',['rows',['../struct_settings.html#a1a6cb4d30bbb550211849ce511a97a1e',1,'Settings']]]
];
