var searchData=
[
  ['playern',['playerN',['../main_8cpp.html#a13fd6cd9014879707fd0f08aecce6066',1,'main.cpp']]],
  ['proxm',['proxM',['../main_8cpp.html#a029be042b871f8f742aa5d9b8c7f229e',1,'main.cpp']]]
];
