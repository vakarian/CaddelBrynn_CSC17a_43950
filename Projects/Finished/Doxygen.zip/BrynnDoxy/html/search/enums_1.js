var searchData=
[
  ['flags',['Flags',['../struct_settings.html#a597300eabbff449b3ab3fbfa991be810',1,'Settings']]]
];
