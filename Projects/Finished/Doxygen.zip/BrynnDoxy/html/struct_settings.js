var struct_settings =
[
    [ "Difficulty", "struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2", [
      [ "BEGINNER", "struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2a0974a94cea76e0d6751d5f185db40ce7", null ],
      [ "INTERMEDIATE", "struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2a98fdde91fafe27e5598354b4c83660b0", null ],
      [ "EXPERT", "struct_settings.html#ab03c07a7c54964db4b281d86b6a345c2a8853822c93a07408991c890336051779", null ]
    ] ],
    [ "Flags", "struct_settings.html#a597300eabbff449b3ab3fbfa991be810", [
      [ "NONE", "struct_settings.html#a597300eabbff449b3ab3fbfa991be810ac7dbfe40df629f75532ba1717c5230d7", null ],
      [ "MINE", "struct_settings.html#a597300eabbff449b3ab3fbfa991be810af47ab0cb506f93cfa6f6b416ce4f224f", null ],
      [ "NOMINE", "struct_settings.html#a597300eabbff449b3ab3fbfa991be810a3f29bdf1c96bc1fb773a31f0609a37b7", null ],
      [ "LOSER", "struct_settings.html#a597300eabbff449b3ab3fbfa991be810aa6636add48a506de3d5a371d31b3f926", null ]
    ] ],
    [ "columns", "struct_settings.html#a3506d9c6fc18cf140974e3872fdefc99", null ],
    [ "field", "struct_settings.html#a8a6a323859d87c7cb4fcb80a919a36de", null ],
    [ "mines", "struct_settings.html#ada9a3fb9dbfef8d3f3aa5da54831a1a4", null ],
    [ "rows", "struct_settings.html#a1a6cb4d30bbb550211849ce511a97a1e", null ]
];