var annotated =
[
    [ "Settings", "struct_settings.html", "struct_settings" ]
];